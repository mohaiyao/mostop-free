<?php
use yii\helpers\Html;
$this->title = $title;
?>

<blockquote class="layui-elem-quote">
    <p>全站缓存数据更新成功</p>
</blockquote>