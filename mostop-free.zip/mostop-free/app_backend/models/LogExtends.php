<?php

namespace app_backend\models;

use Yii;

use common\models\Log;

class LogExtends extends Log
{

}