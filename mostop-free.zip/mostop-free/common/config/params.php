<?php

// 公用项目固定参数值配置
return [
    // 咨询邮箱
    'admin_email' => '494686707@qq.com',

    // 咨询 QQ
    'admin_qq' => '494686707',

    // 系统名称
    'system_name' => 'MOSTOP',

    // 系统 URL
    'system_url' => 'https://mostop.cn/',

    // 版权所有
    'system_copyright_by' => '莫海耀',

    // 团队成员
    'system_development_team' => '莫海耀',

    // 站点配置
    'setting_datas' => [],

    // 视图参数
    'view_params' => [
        'view_css' => '',
        'view_js' => '',
    ],
];