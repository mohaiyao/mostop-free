<?php

// 管理后台项目别名配置
Yii::setAlias('@app_backend', dirname(dirname(__DIR__)) . '/app_backend');

// 公用项目别名配置
Yii::setAlias('@common', dirname(__DIR__));